<?php 
	if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Minstitution extends CI_Model 
	{
		function __construct() 
		{
			parent::__construct();
		}
				
		function find($cari = NULL) 
		{	
			$query = $this->db->query("SELECT * FROM m_institution LIMIT 1");
			$c = $query->result();
			return $c;
		}		
	}
?>