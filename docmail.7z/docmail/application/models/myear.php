<?php 
	if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Myear extends CI_Model 
	{
		function __construct() 
		{
			parent::__construct();
		}
		
		function recordlist() 
		{	
			$query = $this->db->query("SELECT descr FROM m_years ORDER BY descr");

			$c = $query->num_rows();
			return $c;
			//return $query->result();
		}
		
		function find($cari = NULL) 
		{	
			$query = $this->db->query("	SELECT 	descr 
										FROM 	m_years 
										WHERE 	descr LIKE '%$cari%' 
										ORDER BY descr DESC");
			$c = $query->result();
			return $c;
		}
		
		function edit($cari = NULL) 
		{	
			$query = $this->db->query("SELECT descr FROM m_years WHERE descr = '$cari'");
			$c = $query->row();
			return $c;
		}
		
		function delet($cari = NULL) 
		{	
			$query = $this->db->query("DELETE FROM m_years WHERE descr = '$cari'");

			//return $query->result();
		}
		
		function actadd($code = NULL, $descr = NULL) 
		{	
			$query = $this->db->query("INSERT INTO m_years VALUES ('$descr')");

			//return $query->result();
		}
		
		function actedit($cari1 = NULL, $cari2 = NULL) 
		{	
			$query = $this->db->query("UPDATE m_years SET descr = '$cari2' WHERE descr = '$cari1'");

			//return $query->result();
		}
		
		function paginglist($awal = NULL, $akhir = NULL) 
		{	
			$query = $this->db->query("SELECT descr FROM m_years LIMIT $awal, $akhir");
			$c = $query->result();
			return $c;
			//return $query->result();
		}
		
	}
?>