<?php 
	if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Mdocnum extends CI_Model 
	{
		function __construct() 
		{
			parent::__construct();
		}
		
		function recordlist() 
		{	
			$query = $this->db->query("SELECT docnum, title FROM t_docnum order by docnum");

			$c = $query->num_rows();
			return $c;
			//return $query->result();
		}
		
		function find($cari = NULL) 
		{	
			$query = $this->db->query("	SELECT 	docnum, 
												title 
										FROM 	t_docnum 
										WHERE 	docnum LIKE '%$cari%' OR title LIKE '%$cari%' 
										ORDER BY docnum DESC");
			$c = $query->result();
			return $c;
		}
		
		function edit($cari = NULL) 
		{	
			$query = $this->db->query("SELECT * FROM t_docnum WHERE docnum = '$cari'");
			$c = $query->row();
			return $c;
		}
		
		function delet($cari = NULL) 
		{	
			$query = $this->db->query("DELETE FROM t_docnum WHERE docnum = '$cari'");

			//return $query->result();
		}
		
		function actadd($docnum = NULL, $title = NULL, $maildoc = NULL, $month = NULL, $year = NULL, $docdate = NULL, $ho = NULL, $off = NULL, $dar = NULL, $fun = NULL, $pro = NULL, $descr = NULL, $mailto = NULL, $mailpic = NULL) 
		{	
			$seqno = substr($docnum, 4, 4);
			$query = $this->db->query("
										INSERT INTO t_docnum(seqno, docnum, title, docdate, maildoc, 
															 months, years, ho, office, darma, fungsi, 
															 prodi, descr, mailto, mailpic)  
													VALUES  ('$seqno', '$docnum', '$title', '$docdate', 
															 '$maildoc', '$month', '$year', '$ho', '$off', 
															 '$dar', '$fun', '$pro', '$descr', '$mailto', '$mailpic')										
										");

			//return $query->result();
		}
		
		function actedit($cari1 = NULL, $cari2 = NULL) 
		{	
			$query = $this->db->query("UPDATE t_docnum SET title = '$cari2' WHERE docnum = '$cari1'");

			//return $query->result();
		}
		
		function paginglist($awal = NULL, $akhir = NULL) 
		{	
			$query = $this->db->query("SELECT docdate, docnum, title FROM t_docnum LIMIT $awal, $akhir");
			$c = $query->result();
			return $c;
			//return $query->result();
		}
		
		function getheadoffice()
		{			
			$query = $this->db->query('SELECT code, descr FROM m_headoffice ORDER BY code');

			return $query->result();
		}
		
		function getoffice($ho)
		{			
			$office="<option value='0'>-- Choose --</option>";
			$query = $this->db->query("SELECT code, descr FROM m_office WHERE ho = '$ho' ORDER BY code");

			foreach ($query->result_array() as $data )
			{
				$office.= "<option value='$data[code]'>$data[descr]</option>";
			}

			return $office;
		}
				
		function getdarma()
		{			
			$query = $this->db->query('SELECT code, descr FROM m_darma ORDER BY code');

			return $query->result();
		}
	
		function getfungsi()
		{			
			$query = $this->db->query('SELECT code, descr FROM m_function ORDER BY code');

			return $query->result();
		}
		
		function getprodi()
		{			
			$query = $this->db->query('SELECT code, descr FROM m_prodi ORDER BY code');

			return $query->result();
		}
		
		function getmonths()
		{			
			$query = $this->db->query('SELECT code, descr FROM m_months ORDER BY code');

			return $query->result();
		}
		
		function getyears()
		{			
			$query = $this->db->query('SELECT descr FROM m_years ORDER BY descr');

			return $query->result();
		}
		
		function search($ho = NULL)
		{
			/*$query = $this->db->query("
										SELECT 	ifnull(max(seqno)+1, '1') AS last 
										FROM 	t_docnum 
										WHERE	substring(docnum,1,1)  = $maildoc and 												
												substring(docnum,10,2) = $month and
												substring(docnum,13,2) = $year and
												substring(docnum,3,1)  = $ho and 
												substring(docnum,16,2) = $off and
												substring(docnum,19,2) = $dar and 
												substring(docnum,22,2) = $fun and 
												substring(docnum,25,2) = $pro
										");*/
			
			$query = $this->db->query("
										SELECT 	ifnull(max(seqno)+1, '1') AS last 
										FROM 	t_docnum 
										WHERE	substring(docnum,3,1)  = $ho 
										");			
								
								/* 
								1/1/0001/01/17/03/05/04/01	
								1   : out
								1	: head office
								0001: nomor urut
								01  : bulan
								17  : tahun
								03  : office
								05  : darma
								04  : fungsi
								01  : prodi
								*/

			$rowcount = $query->num_rows();
			
			if($rowcount > 0)
			{
				$row = $query->row(); 				
				$res = $row->last;				
				$num = strlen($res);

				switch ($num) 
				{
					case 1:
						$nums = '000'.$res;
						break;
					case 2:
						$nums = '00'.$res;
						break;
					case 3:
						$nums = '0'.$res;
						break;
					default:
						$nums = $res;
				}
			}
			else 
			{
				$nums = '0001'; 
			}
			
			return $nums;
		}		
	}
?>