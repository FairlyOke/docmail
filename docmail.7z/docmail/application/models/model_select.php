<?php
	Class Model_select extends CI_Model
	{
		function __construct()
		{
			parent::__construct();
		}
		
		function provinsi()
		{
			$this->db->order_by('code','ASC');
			$provinces= $this->db->get('m_headoffice');
			return $provinces->result_array();
		}
		
		function kabupaten($provId)
		{
			$kabupaten="<option value='0'>--pilih--</option>";
			$this->db->order_by('code','ASC');
			$kab= $this->db->get_where('m_office',array('ho'=>$provId));
			
			foreach ($kab->result_array() as $data )
			{
				$kabupaten.= "<option value='$data[code]'>$data[descr]</option>";
			}
			
			return $kabupaten;
		}
	}