<div class="clearfix">
	<div class="row">
		<div class="col-lg-12">
			<div class="navbar navbar-inverse">
				<div class="container">
					<div class="navbar-header">
						<a class="navbar-brand" href="#">Office List</a>
					</div>					
					<div class="navbar-collapse collapse navbar-inverse-collapse" style="margin-right: -20px">
						<?php 
							/*if ($this->session->userdata('admin_level') == "admin") 
							{*/
						?>
								<ul class="nav navbar-nav">
									<li><a href="<?php echo base_URL(); ?>index.php/office/officerecord/add" class="btn-info"><i class="icon-plus-sign icon-white"> </i> Add Record</a></li>
								</ul>
						<?php 
							/*} 
							else 
							{
								echo "";
							}*/
						?>
						<ul class="nav navbar-nav navbar-right">
							<form class="navbar-form navbar-left" method="post" action="<?php echo base_URL(); ?>index.php/office/officerecord/find">
								<input type="text" class="form-control" name="q" style="width: 200px" placeholder="Searching keyword ..." required>
								<button type="submit" class="btn btn-danger"><i class="icon-search icon-white"> </i> Find</button>
							</form>
						</ul>
					</div><!-- /.nav-collapse -->
				</div><!-- /.container -->
			</div><!-- /.navbar -->
		</div>
	</div>

	<?php echo $this->session->flashdata("k");?>
	
	<table class="table table-bordered table-hover">
		<thead>
			<tr>
				<th width="10%">Code</th>
				<th width="70%">Description</th>
				<th width="20%">Action</th>
			</tr>
		</thead>
	
		<tbody>
		<?php 
			if (empty($data)) 
			{
				echo "<tr><td colspan='5'  style='text-align: center; font-weight: bold'>--No data--</td></tr>";
			} 
			else 
			{
				$no 	= ($this->uri->segment(4) + 1);
				foreach ($data as $b) 
				{
		?>
			<tr>
				<td align="center"><?php echo $b->code; ?></td>
				<td><?php echo $b->descr; ?></td>
			<?php 
					/*if ($this->session->userdata('admin_level') == "admin") 
					{*/
			?>
				<td class="ctr">					
					<div class="btn-group">
						<a href="<?php echo base_URL(); ?>index.php/office/officerecord/edt/<?php echo $b->code; ?>" class="btn btn-success btn-sm" title="Edit Data"><i class="icon-edit icon-white"> </i> Edit</a> <a href="<?php echo base_URL(); ?>index.php/office/officerecord/del/<?php echo $b->code; ?>" class="btn btn-warning btn-sm" title="Delete Data" onclick="return confirm('Are you sure...?')"><i class="icon-trash icon-remove"> </i> Delete</a>								
					</div>				
				</td>
			<?php 
					/*} 
					else 
					{
						echo "<td class='ctr'> -- </td>";
					}*/
			?>
			</tr>
			<?php 
					$no++;
				}
			}
			?>
		</tbody>
	</table>
	<center>
		<ul class="pagination"><?php echo $pagi; ?></ul>
	</center>
</div>
