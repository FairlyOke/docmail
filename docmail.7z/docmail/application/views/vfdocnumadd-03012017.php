<div class="navbar navbar-inverse">
	<div class="container z0">
		<div class="navbar-header">
			<span class="navbar-brand" href="#">Document Number</span>
		</div>
	</div><!-- /.container -->
</div><!-- /.navbar -->

<form action="<?php echo base_URL(); ?>index.php/docnum/docnumgenerate" method="post" accept-charset="utf-8" enctype="multipart/form-data">
	<div class="row-fluid well" style="overflow: hidden">
		<div class="col-lg-6">
			<table width="1000px" class="table-form" border = '0'>
				<tr>
					<td width="15%">Mail Doc</td>
					<td colspan="3">
						<b><input type="radio" name="maildoc" value="2"> In</input>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="maildoc" value="1" checked> Out</input></b>
					</td>
				<tr>
					<td>Month</td>
					<td width="35%">
						<b>
							<select name="month" style="width: 200px">
							<?php 
								foreach($months as $row)
								{ 
									$month = $row->code;									
									echo '<option value="'.$month.'">'.$row->descr.'</option>';									
								}
							?>
							</select>
						</b>
					</td>						
					<td width="15%">Office</td>
					<td width="35%">
						<b>
							<select name="off" style="width: 200px">
							<?php 
								foreach($office as $row)
								{ 
									$off = $row->code;
									echo '<option value="'.$off.'">'.$row->descr.'</option>';
								}
							?>
							</select>
						</b>
					</td>
				</tr>
				<tr>
					<td>Year</td>
					<td>
						<b>
							<select name="year" style="width: 200px">
							<?php 
								foreach($years as $row)
								{ 
									$year = substr($row->descr, 2, 2);
									echo '<option value="'.$year.'">'.$row->descr.'</option>';
								}
							?>
							</select>
						</b>
					</td>
					<td>Darma</td>
					<td>
						<b>
							<select name="dar" style="width: 200px">
							<?php 
								foreach($darma as $row)
								{ 
									$dar = $row->code;
									echo '<option value="'.$dar.'">'.$row->descr.'</option>';
								}
							?>
							</select>
						</b>
					</td>
				</tr>						
				<tr>
					<td></td><td></td>
					<td>Function</td>
					<td>
						<b>
							<select name="fun" style="width: 200px">
							<?php 
								foreach($fungsi as $row)
								{ 
									$fun = $row->code;
									echo '<option value="'.$fun.'">'.$row->descr.'</option>';
								}
							?>
							</select>
						</b>
					</td>
				</tr>
				<tr>
					<td></td><td></td>
					<td>Program Studi</td>
					<td>
						<b>
							<select name="pro" style="width: 200px">
							<?php 
								foreach($prodi as $row)
								{ 
									$pro = $row->code;
									echo '<option value="'.$pro.'">'.$row->descr.'</option>';
								}
							?>
							</select>
						</b>
					</td>
				</tr>
				<tr>
					<td>Document Title</td>
					<td colspan="3"><b><input type="text" name="title" tabindex="2" required id="descr" style="width: 850px" class="form-control"></b>
					</td>
				</tr>					
				<tr>
					<td colspan="4">
						<br><button type="submit" class="btn btn-primary" tabindex="10" ><i class="icon icon-ok icon-white"> </i> Generate</button>
						<a href="<?php echo base_URL(); ?>index.php/docnum/docnumlist" class="btn btn-success" tabindex="11" ><i class="icon icon-arrow-left icon-white"> </i> Back</a>
					</td>
				</tr>
			</table>
		</div>
	</div>
</form>
