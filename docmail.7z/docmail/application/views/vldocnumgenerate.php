<div class="clearfix">
	<div class="row">
		<div class="col-lg-12">
			<div class="navbar navbar-inverse">
				<div class="container">
					<div class="navbar-header">
						<a class="navbar-brand" href="#">Document Number Generate</a>
					</div>					
				</div><!-- /.container -->
			</div><!-- /.navbar -->
		</div>
	</div>

	<?php echo $this->session->flashdata("k");?>
	
	<table class="table table-bordered table-hover">		
		<tbody>
		<?php 
			if (empty($data)) 
			{
				echo "<tr><td colspan='2'  style='text-align: center; font-weight: bold'>--No data--</td></tr>";
			} 
			else 
			{
				//foreach ($data as $b) 
				//{
		?>
			<tr>				
				<td width="15%"><strong>Document Date</strong></td><td><?php echo date("d-M-Y", strtotime($docdate)); //echo $b->docnum; ?></td>
			</tr>						
			<?php
				if ($stat=="edt")
				{
					echo '	<tr>				
								<td width="15%"><strong>Old Document No.</strong></td><td>'.$docnum1.'</td>
							</tr>	
							<tr>				
								<td width="15%"><strong>New Document No.</strong></td><td>'.$docnum2.'</td>
							</tr>';
				}
				else
				{
					echo '	<tr>				
								<td width="15%"><strong>Old Document No.</strong></td><td>'.$docnum.'</td>
							</tr>';	
				}
			?>
			<tr>
				<td><strong>Document Title</strong></td><td><?php echo $title; //echo $b->title; ?></td>
			</tr>
			<?php 					
				//}
			}
			?>
			<tr>
				<td colspan="4">
					<br>
					<a href="<?php echo base_URL(); ?>index.php/docnum/docnumlist" class="btn btn-success" tabindex="11" ><i class="icon icon-arrow-left icon-white"> </i> OK</a>
				</td>
			</tr>
		</tbody>
	</table>	
</div>
