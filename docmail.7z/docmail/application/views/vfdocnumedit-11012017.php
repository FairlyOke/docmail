<?php
	$mode = $this->uri->segment(3);

	if ($mode == "edt" || $mode == "act_edt") 
	{
		$act   = "act_edt";
		//$idp   = $datpil->id;
		$code  = $datpil->docnum;
		$descr = $datpil->title;
	} 
	else 
	{
		$act   = "act_add";
		$idp   = "";
		$code  = gli("t_docnum", "docnum", 25);
		$descr = "";		
	}
?>
<div class="navbar navbar-inverse">
	<div class="container z0">
		<div class="navbar-header">
			<span class="navbar-brand" href="#">Document Number</span>
		</div>
	</div><!-- /.container -->
</div><!-- /.navbar -->

<form action="<?php echo base_URL(); ?>index.php/docnum/docnumrecord/<?php echo $act; ?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">
	<input type="hidden" name="code" value="<?php echo $code; ?>">
		<div class="row-fluid well" style="overflow: hidden">
			<div class="col-lg-6">
				<table width="1000px" class="table-form" border = '0'>					
					<tr>
						<td>Document Number</td>
						<td colspan="3"><b><?php echo $code; ?></b></td>
						<td>Date</td>
						<td colspan="3"><b><?php echo $code; ?></b></td>
					</tr>
					<tr>
						<td>Document Title</td>
						<td colspan="2"><b><input type="text" name="descr" tabindex="2" required value="<?php echo $descr; ?>" id="descr" style="width: 800px" class="form-control"></b>
						</td>						
					</tr>
					<tr>
						<td colspan="4">
							<br><button type="submit" class="btn btn-primary" tabindex="10" ><i class="icon icon-ok icon-white"> </i> Save</button>
							<a href="<?php echo base_URL(); ?>index.php/docnum/docnumlist" class="btn btn-success" tabindex="11" ><i class="icon icon-arrow-left icon-white"> </i> Back</a>
						</td>
					</tr>
				</table>
			</div>
		</div>
</form>
