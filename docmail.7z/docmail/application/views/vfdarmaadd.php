<?php
	$mode = $this->uri->segment(3);

	if ($mode == "edt" || $mode == "act_edt") 
	{
		$act   = "act_edt";
		//$idp   = $datpil->id;
		$code  = $datpil->code;
		$descr = $datpil->descr;
	} 
	else 
	{
		$act   = "act_add";
		$idp   = "";
		$code  = gli("m_darma", "code", 2);
		$descr = "";		
	}
?>
<div class="navbar navbar-inverse">
	<div class="container z0">
		<div class="navbar-header">
			<span class="navbar-brand" href="#">Darma List</span>
		</div>
	</div><!-- /.container -->
</div><!-- /.navbar -->

<form action="<?php echo base_URL(); ?>index.php/darma/darmarecord/<?php echo $act; ?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">
	<input type="hidden" name="code" value="<?php echo $code; ?>">
		<div class="row-fluid well" style="overflow: hidden">
			<div class="col-lg-6">
				<table  class="table-form">
					<tr>
						<td width="20%">Code</td><td><b><input type="text" name="code" autofocus tabindex="1" required value="<?php echo $code; ?>" style="width: 100px" class="form-control" readonly></b>
						</td>
					</tr>
					<tr>
						<td width="20%">Description</td><td><b><input type="text" name="descr" tabindex="2" required value="<?php echo $descr; ?>" id="descr" style="width: 400px" class="form-control"></b>
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<br><button type="submit" class="btn btn-primary" tabindex="10" ><i class="icon icon-ok icon-white"> </i> Save</button>
							<a href="<?php echo base_URL(); ?>index.php/darma/darmarecord" class="btn btn-success" tabindex="11" ><i class="icon icon-arrow-left icon-white"> </i> Back</a>
						</td>
					</tr>
				</table>
			</div>
		</div>
</form>
