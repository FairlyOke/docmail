<?php
	$mode = $this->uri->segment(3);

	if ($mode == "edt" || $mode == "act_edt") 
	{
		$act   = "act_edt";
		//$idp   = $datpil->id;		
		$docnum 	= $datpil->docnum;
		$title 		= $datpil->title;
		$docdate 	= $datpil->docdate;
		$maildoc 	= $datpil->maildoc;
		$mon	 	= $datpil->months;
		$yea 		= $datpil->years;
		$ho1 		= $datpil->ho;
		$offi	 	= $datpil->office;
		$dar 		= $datpil->darma;
		$fun	 	= $datpil->fungsi;
		$pro 		= $datpil->prodi;
		$mailto 	= $datpil->mailto;
		$descr	 	= $datpil->descr;
		$mailpic 	= $datpil->mailpic;
		
	} 
	else 
	{
		$act   = "act_add";
		$idp   = "";
		$code  = gli("t_docnum", "docnum", 25);
		$descr = "";		
	}
?>
<div class="navbar navbar-inverse">
	<div class="container z0">
		<div class="navbar-header">
			<span class="navbar-brand" href="#">Document Number</span>
		</div>
	</div><!-- /.container -->
</div><!-- /.navbar -->

<form action="<?php echo base_URL(); ?>index.php/docnum/docnumedit" method="post" accept-charset="utf-8" enctype="multipart/form-data">
	<div class="row-fluid well" style="overflow: hidden">
		<div class="col-lg-6">
			<table width="1000px" class="table-form" border = '0'>
				<tr>
					<td width="15%">Document No</td>
					<td colspan="4">
						<b>
							<input type="text" name="docno" tabindex="1" required id="docno" style="width: 250px" class="form-control" value="<?php echo $docnum; ?>" readonly>
						</b>					
					</td>
				</tr>
				<tr>
					<td width="15%">Mail Doc</td>
					<td colspan="4">
						<?php
							if ($act == "act_edt")
							{
								if ($maildoc == "0")
								{
									echo '<b><input type="radio" name="maildoc" value="0" tabindex="2" checked> In</input>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="maildoc" value="1" tabindex="3" > Out</input></b>';			
								}
								else
								{
									echo '<b><input type="radio" name="maildoc" value="0" tabindex="2"> In</input>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="maildoc" value="1" checked tabindex="3" > Out</input></b>';		
								}
							}
							else
							{
								echo '<b><input type="radio" name="maildoc" value="0" tabindex="2"> In</input>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="maildoc" value="1" checked tabindex="3" > Out</input></b>';
							}
						?>						
					</td>
				</tr>
				<tr>
					<td>Month</td>
					<td width="35%" colspan="2">
						<b>
							<select name="month" style="width: 200px" class="form-control" tabindex="4" >
							<option value='0'>-- Choose --</option>
							<?php 
								foreach($months as $row)
								{ 
									$month = $row->code;																			
									if ($act == "act_edt")
									{	
										if ($month == $mon)
										{
											echo '<option value="'.$month.'" selected>'.$row->descr.'</option>';
										}
										else
										{
											echo '<option value="'.$month.'">'.$row->descr.'</option>';
										}
									}
									else
									{
										echo '<option value="'.$month.'">'.$row->descr.'</option>';
									}
								}
								
							?>
							</select>
						</b>
					</td>	
					<td width="15%">Head Office</td>
					<td width="35%">
						<b>
							<select name="ho" id="ho" style="width: 200px" class="form-control" tabindex="11" >
							<option value="0">-- Choose --</option>
							<?php 
								foreach($headoffice as $row)
								{ 
									$off = $row->code;									
									if ($act == "act_edt")
									{	
										if ($off == $ho1)
										{
											echo '<option value="'.$off.'" selected>'.$row->descr.'</option>';
										}
										else
										{
											echo '<option value='.$off.'>'.$row->descr.'</option>';
										}
									}
									else
									{
										echo '<option value='.$off.'>'.$row->descr.'</option>';
									}
								}
							?>
							</select>
						</b>
					</td>
				</tr>
				<tr>
					<td>Year</td>
					<td  colspan="2">
						<b>
							<select name="year" style="width: 200px" class="form-control" tabindex="5" >
							<option value='0'>-- Choose --</option>
							<?php 
								foreach($years as $row)
								{ 
									$year = substr($row->descr, 2, 2);
									echo '<option value="'.$year.'">'.$row->descr.'</option>';
									if ($act == "act_edt")
									{	
										if ($year == $yea)
										{
											echo '<option value="'.$year.'" selected>'.$row->descr.'</option>';
										}
										else
										{
											
										}
									}
									else
									{
										
									}
								}
							?>
							</select>
						</b>
					</td>
					<td width="15%">Office</td>
					<td width="35%">
						<b>
							<select name="off" id="off" style="width: 200px" class="form-control" tabindex="12" >
							<option value="0">-- Choose --</option>	
							<?php 
								foreach($office as $row)
								{ 
									$offs = $row->code;									
									if ($act == "act_edt")
									{	
										if ($offs == $offi)
										{
											echo '<option value="'.$offs.'" selected>'.$row->descr.'</option>';
										}
										else
										{									
										}
									}
									else
									{										
									}
								}
							?>
							</select>
						</b>
					</td>					
				</tr>						
				<tr>
					<td>Date</td>
					<td width="5%">
						<b>
							<a href="javascript:NewCssCal('docdate','ddmmmyyyy')">
								<img src="<?php echo base_url()?>asset/img/cal.gif" width="16" height="16" border="0" alt="Pick a date" class="form-control" style="width:50px;" tabindex="6" >
							</a>
						</b>
					</td>
					<td width="30%">
						<?php
							if ($act == "act_edt")
							{	
								echo '<b><input readonly="true" name="docdate" id="docdate" type="text" style="width:110px; text-align:center;" value="'.date('d-M-Y', strtotime($docdate)).'" class="form-control"></b>';
							}
							else
							{
								
							}
						?>
					</td>
					<td>Darma</td>
					<td>
						<b>
							<select name="dar" style="width: 200px" class="form-control" tabindex="13" >
							<option value='0'>-- Choose --</option>
							<?php 
								foreach($darma as $row)
								{ 
									$dars = $row->code;									
									if ($act == "act_edt")
									{	
										if ($dars == $dar)
										{
											echo '<option value="'.$dars.'" selected>'.$row->descr.'</option>';
										}
										else
										{
											echo '<option value="'.$dar.'">'.$row->descr.'</option>';
										}
									}
									else
									{
										echo '<option value="'.$dar.'">'.$row->descr.'</option>';
									}
								}
							?>
							</select>
						</b>
					</td>					
				</tr>
				<tr>
					<td>Mail To</td>
					<td colspan="2"><b><input type="text" name="mailto" tabindex="2" required id="mailto" style="width: 325px" class="form-control" value="<?php echo $mailto; ?>" tabindex="7" ></b></td>
					<td>Function</td>
					<td>
						<b>
							<select name="fun" style="width: 200px" class="form-control" tabindex="14" >
							<option value='0'>-- Choose --</option>
							<?php 
								foreach($fungsi as $row)
								{ 
									$funs = $row->code;									
									if ($act == "act_edt")
									{	
										if ($funs == $fun)
										{
											echo '<option value="'.$funs.'" selected>'.$row->descr.'</option>';
										}
										else
										{
											echo '<option value="'.$funs.'">'.$row->descr.'</option>';
										}
									}
									else
									{
										echo '<option value="'.$funs.'">'.$row->descr.'</option>';
									}
								}
							?>
							</select>
						</b>
					</td>					
				</tr>
				<tr>
					<td>Mail PIC</td>
					<td colspan="2"><b><input type="text" name="mailpic" tabindex="2" required id="mailpic" style="width: 325px" class="form-control" value="<?php echo $mailpic; ?>" tabindex="8" ></b></td>
					<td>Program Studi</td>
					<td>
						<b>
							<select name="pro" style="width: 200px" class="form-control" tabindex="15" >
							<option value='0'>-- Choose --</option>
							<?php 
								foreach($prodi as $row)
								{ 
									$pros = $row->code;									
									if ($act == "act_edt")
									{	
										if ($pros == $pro)
										{
											echo '<option value="'.$pros.'" selected>'.$row->descr.'</option>';
										}
										else
										{
											echo '<option value="'.$pros.'">'.$row->descr.'</option>';
										}
									}
									else
									{
										echo '<option value="'.$pros.'">'.$row->descr.'</option>';
									}
								}
							?>
							</select>
						</b>
					</td>
				</tr>
				<tr>
					<td>Document Title</td>
					<td colspan="4"><b><input type="text" name="title" tabindex="2" required id="title" style="width: 850px" class="form-control" value="<?php echo $title; ?>" tabindex="16" ></b>
					</td>
				</tr>					
				<tr>
					<td>Description</td>
					<td colspan="4"><b><input type="text" name="descr" tabindex="2" required id="descr" style="width: 850px" class="form-control" value="<?php echo $descr; ?>" tabindex="17" ></b>
					</td>
				</tr>					
				<tr>
					<td colspan="5">
						<br><button type="submit" class="btn btn-primary" tabindex="10" ><i class="icon icon-ok icon-white"> </i> Update</button>
						<a href="<?php echo base_URL(); ?>index.php/docnum/docnumlist" class="btn btn-success" tabindex="11" ><i class="icon icon-arrow-left icon-white"> </i> Back</a>
					</td>
				</tr>
			</table>
		</div>
	</div>
</form>
