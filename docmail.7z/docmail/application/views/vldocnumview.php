<?php
	$mode = $this->uri->segment(3);

	if ($mode == "viw")
	{
		$act   = "viw";		
		$docnum = $data->docnum;
		$docdate = $data->docdate;
		$docdate = date("d-M-Y", strtotime($docdate));
		$mailto	 = $data->mailto;
		$mailpic = $data->mailpic;
		$title	 = $data->title;		
		$descr	 = $data->descr;
	} 
	else 
	{
		$act   = "act_add";
		$idp   = "";
		$code  = gli("t_docnum", "docnum", 25);
		$descr = "";		
	}
?>
<div class="navbar navbar-inverse">
	<div class="container z0">
		<div class="navbar-header">
			<span class="navbar-brand" href="#">Document Number</span>
		</div>
	</div><!-- /.container -->
</div><!-- /.navbar -->

<div class="row-fluid well" style="overflow: hidden">
	<div class="col-lg-6">
		<table width="900px" border = '0' class="table-hover">					
			<tr>
				<td width="15%">Document Number</td>
				<td width="85%"><b><?php echo $docnum; ?></b></td>				
			</tr>
			<tr>
				<td>Date</td>
				<td><b><?php echo $docdate; ?></b></td>
			</tr>
			<tr>
				<td>Mail To</td>
				<td><b><?php echo $mailto; ?></b></td>
			</tr>
			<tr>
				<td>Mail PIC</td>
				<td colspan="3"><b><?php echo $mailpic; ?></b></td>				
			</tr>
			<tr>
				<td>Document Title</td>
				<td><?php echo $title; ?></b></td>						
			</tr>
			<tr>
				<td>Description</td>
				<td><?php echo $descr; ?></b></td>						
			</tr>
			<tr>
				<td colspan="4">
					<br><a href="<?php echo base_URL(); ?>index.php/docnum/docnumlist" class="btn btn-success" tabindex="11" ><i class="icon icon-arrow-left icon-white"> </i> OK</a>
				</td>
			</tr>
		</table>
	</div>
</div>
