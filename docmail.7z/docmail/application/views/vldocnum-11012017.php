<div class="clearfix">
	<div class="row">
		<div class="col-lg-12">
			<div class="navbar navbar-inverse">
				<div class="container">
					<div class="navbar-header">
						<a class="navbar-brand" href="#">Document Number List</a>
					</div>
					<div class="navbar-collapse collapse navbar-inverse-collapse" style="margin-right: -20px">
						<ul class="nav navbar-nav">
							<li><a href="<?php echo base_URL(); ?>index.php/docnum/docnumrecord/add" class="btn-info"><i class="icon-plus-sign icon-white"> </i> Add Record</a></li>
						</ul>
						<ul class="nav navbar-nav navbar-right">
							<form class="navbar-form navbar-left" method="post" action="<?php echo base_URL(); ?>index.php/docnum/docnumlist/find">
								<input type="text" class="form-control" name="q" style="width: 200px" placeholder="Searching keyword ..." required>
								<button type="submit" class="btn btn-danger"><i class="icon-search icon-white"> </i> Find</button>
							</form>
						</ul>
					</div><!-- /.nav-collapse -->
				</div><!-- /.container -->
			</div><!-- /.navbar -->
		</div>
	</div>

	<?php echo $this->session->flashdata("k");?>
	
	<table class="table table-bordered table-hover" width="900px">
		<thead>
			<tr>				
				<th width="5%">No</th>
				<th width="10%">Date</th>
				<th width="20%">Code</th>				
				<th width="50%">Title</th>				
				<th width="15%">Action</th>
			</tr>
		</thead>
	
		<tbody>
		<?php 
			if (empty($data)) 
			{
				echo "<tr><td colspan='5'  style='text-align: center; font-weight: bold'>--No data--</td></tr>";
			} 
			else 
			{
				$no 	= ($this->uri->segment(4) + 1);
				foreach ($data as $b) 
				{
		?>
			<tr>
				<td align="center"><?php echo $no; ?></td>
				<td align="center"><?php echo date("d-M-Y", strtotime($b->docdate)); ?></td>
				<td align="center"><?php echo $b->docnum; ?></td>
				<td><?php echo $b->title; ?></td>
			<?php 
					/*if ($this->session->userdata('admin_level') == "admin") 
					{*/
			?>
				<td class="ctr">
					<div class="btn-group">
						<a href="<?php echo base_URL(); ?>index.php/docnum/docnumrecord/viw/<?php echo $b->docnum; ?>" class="btn btn-success btn-sm" title="View Data"><i class="icon-trash icon-edit"> </i> View</a>
						<a href="<?php echo base_URL(); ?>index.php/docnum/docnumrecord/del/<?php echo $b->docnum; ?>" class="btn btn-warning btn-sm" title="Delete Data" onclick="return confirm('Are you sure...?')"><i class="icon-trash icon-remove"> </i> Delete</a>								
					</div>					
				</td>
			<?php 
					/*} 
					else 
					{
						echo "<td class='ctr'> -- </td>";
					}*/
			?>
			</tr>
			<?php 
					$no++;
				}
			}
			?>
		</tbody>
	</table>
	<center>
		<ul class="pagination"><?php echo $pagi; ?></ul>
	</center>
</div>
