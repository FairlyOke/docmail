<?php 
	if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Office extends CI_Controller 
	{
		function __construct() 
		{
			parent::__construct();			
			$this->load->model('Moffice');
		}
	
		public function index()
		{
			if ($this->session->userdata('admin_valid') == FALSE && $this->session->userdata('admin_id') == "") 
			{
				redirect("index.php/general/login");
			}	
		
			$a['page']	= "d_amain";
			$this->load->view('aaa', $a);			
		}
	
		public function officelist() 
		{
			if ($this->session->userdata('admin_valid') == FALSE && $this->session->userdata('admin_id') == "") 
			{
				redirect("index.php/general/login");
			}
		
			/* pagination */				
			$total_row		= $this->Moffice->recordlist();
			$per_page		= 10;
		
			$awal	= $this->uri->segment(4); 
			$awal	= (empty($awal) || $awal == 1) ? 0 : $awal;
		
			//if (empty($awal) || $awal == 1) { $awal = 0; } { $awal = $awal; }
			$akhir	= $per_page;
		
			$a['pagi']	= _page($total_row, $per_page, 4, base_url()."index.php/office/officelist/p");
		
			//ambil variabel URL
			$mau_ke					= $this->uri->segment(3);
			$idu					= $this->uri->segment(4);
		
			$cari					= addslashes($this->input->post('q'));

			//ambil variabel Postingan			
			$code					= addslashes($this->input->post('code'));
			$descr					= addslashes($this->input->post('descr'));
			$cari					= addslashes($this->input->post('q'));
		
			if ($mau_ke == "find") 
			{
				$a['data']	= $this->Moffice->find($cari);
				$a['page']	= "vloffice";
			} 
			else
			{
				$a['data']		= $this->Moffice->paginglist($awal, $akhir);
				$a['page']		= "vloffice";
			}
			
			$this->load->view('aaa', $a);
		}
	
		public function officerecord() 
		{
			if ($this->session->userdata('admin_valid') == FALSE && $this->session->userdata('admin_id') == "") 
			{
				redirect("index.php/general/login");
			}
		
			$ta = $this->session->userdata('admin_ta');
		
			/* pagination */	
			$total_row		= $this->Moffice->recordlist();
			$per_page		= 10;
		
			$awal	= $this->uri->segment(4); 
			$awal	= (empty($awal) || $awal == 1) ? 0 : $awal;
		
			//if (empty($awal) || $awal == 1) { $awal = 0; } { $awal = $awal; }
			$akhir	= $per_page;
		
			$a['pagi']	= _page($total_row, $per_page, 4, base_url()."index.php/office/officelist/p");
		
			//ambil variabel URL
			$mau_ke					= $this->uri->segment(3);
			$idu					= $this->uri->segment(4);
		
			$cari					= addslashes($this->input->post('q'));

			//ambil variabel post
			$idp					= addslashes($this->input->post('idp'));
			$code					= addslashes($this->input->post('code'));
			$descr 				    = addslashes($this->input->post('descr'));			
			
			$cari					= addslashes($this->input->post('q'));
			
			//upload config 
			$config['upload_path'] 		= './upload/surat_masuk';
			$config['allowed_types'] 	= 'gif|jpg|png|pdf|doc|docx';
			$config['max_size']			= '2000';
			$config['max_width']  		= '3000';
			$config['max_height'] 		= '3000';

			$this->load->library('upload', $config);

			if ($mau_ke == "del") 
			{
				$this->Moffice->delet($idu);
				$this->session->set_flashdata("k", "<div class=\"alert alert-success\" id=\"alert\">Data has been deleted </div>");
				redirect('index.php/office/officerecord');
			} 
			else if ($mau_ke == "add") 
			{
				$a['page']		= "vfofficeadd";
			} 
			else if ($mau_ke == "edt") 
			{
				$a['datpil']	= $this->Moffice->edit($idu);
				$a['page']		= "vfofficeadd";
			} 
			else if ($mau_ke == "act_add") 
			{	
				$this->Moffice->actadd($code, $descr);
				
				$this->session->set_flashdata("k", "<div class=\"alert alert-success\" id=\"alert\">Data has been added. ".$this->upload->display_errors()."</div>");
				redirect('index.php/office/officerecord');
			} 
			else if ($mau_ke == "act_edt") 
			{
				$this->Moffice->actedit($code, $descr);
				
				$this->session->set_flashdata("k", "<div class=\"alert alert-success\" id=\"alert\">Data has been updated. ".$this->upload->display_errors()."</div>");			
				redirect('index.php/office/officerecord');
			} 
			else 
			{
				$a['data']		= $this->Moffice->paginglist($awal, $akhir);
				$a['page']		= "vlofficeadd";
			}
		
			$this->load->view('aaa', $a);
		}
	
	}
?>