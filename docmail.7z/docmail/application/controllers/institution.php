<?php 
	if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Institution extends CI_Controller 
	{
		function __construct() 
		{
			parent::__construct();			
			$this->load->model('Minstitution');
		}
	
		public function index()
		{
			if ($this->session->userdata('admin_valid') == FALSE && $this->session->userdata('admin_id') == "") 
			{
				redirect("index.php/login");
			}	
		
			$a['page']	= "d_amain";
			$this->load->view('aaa', $a);			
		}
	
		public function institutionlist() 
		{
			if ($this->session->userdata('admin_valid') == FALSE && $this->session->userdata('admin_id') == "") 
			{
				redirect("index.php/login");
			}
		
			$a['data'] = $this->Minstitution->find();									
			$this->load->view('aaa', $a);
		}
	}
?>