<?php
	Class Select extends CI_Controller
	{
		function __construct()
		{
			parent::__construct();
			$this->load->database();
			$this->load->helper(array('url'));
			$this->load->model('model_select');
		}
		
		function index()
		{
			$data['provinsi']=$this->model_select->provinsi();
			$this->load->view('views_select',$data);
		}
		
		function getdata()
		{
			$modul=$this->input->post('modul');
			$id=$this->input->post('id');
			
			if($modul=="kabupaten")
			{
				echo $this->model_select->kabupaten($id);
			}
			else
			{
				
			}
		}
	}