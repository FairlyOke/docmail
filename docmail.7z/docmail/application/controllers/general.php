<?php 
	if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class General extends CI_Controller 
	{
		function __construct() 
		{
			parent::__construct();
		}
	
		public function index() 
		{
			if ($this->session->userdata('admin_valid') == FALSE && $this->session->userdata('admin_id') == "") 
			{
				redirect("index.php/general/login");
			}
		
			$a['page']	= "d_amain";
		
			$this->load->view('aaa', $a);
		}
	
		public function users() 
		{
			if ($this->session->userdata('admin_valid') == FALSE && $this->session->userdata('admin_id') == "") 
			{
				redirect("index.php/general/login");
			}		
		
			//ambil variabel URL
			$mau_ke					= $this->uri->segment(3);
		
			//ambil variabel Postingan
			$idp					= addslashes($this->input->post('idp'));
			$nama					= addslashes($this->input->post('nama'));
			$alamat					= addslashes($this->input->post('alamat'));
			$kepsek					= addslashes($this->input->post('kepsek'));
			$nip_kepsek				= addslashes($this->input->post('nip_kepsek'));
			
			$cari					= addslashes($this->input->post('q'));

			//upload config 
			$config['upload_path'] 		= './upload';
			$config['allowed_types'] 	= 'gif|jpg|png|pdf|doc|docx';
			$config['max_size']			= '2000';
			$config['max_width']  		= '3000';
			$config['max_height'] 		= '3000';

			$this->load->library('upload', $config);
		
			if ($mau_ke == "act_edt") 
			{
				if ($this->upload->do_upload('logo')) 
				{
					$up_data	 	= $this->upload->data();
				
					$this->db->query("UPDATE m_institution SET nama = '$nama', alamat = '$alamat', kepsek = '$kepsek', nip_kepsek = '$nip_kepsek', logo = '".$up_data['file_name']."' WHERE id = '$idp'");

				} 
				else 
				{
					$this->db->query("UPDATE m_institution SET nama = '$nama', alamat = '$alamat', kepsek = '$kepsek', nip_kepsek = '$nip_kepsek' WHERE id = '$idp'");
				}		

				$this->session->set_flashdata("k", "<div class=\"alert alert-success\" id=\"alert\">Data has been updated</div>");			
				redirect('index.php/general/users');
			} 
			else 
			{
				$a['data']		= $this->db->query("SELECT * FROM m_institution WHERE id = '1' LIMIT 1")->row();
				$a['page']		= "fusers";
			}
		
			$this->load->view('aaa', $a);	
		}	
		
		public function manageusers() 
		{
			if ($this->session->userdata('admin_valid') == FALSE && $this->session->userdata('admin_id') == "") 
			{
				redirect("index.php/general/login");
			}
		
			/* pagination */	
			$total_row		= $this->db->query("SELECT * FROM m_users")->num_rows();
			$per_page		= 10;
		
			$awal	= $this->uri->segment(4); 
			$awal	= (empty($awal) || $awal == 1) ? 0 : $awal;
		
			//if (empty($awal) || $awal == 1) { $awal = 0; } { $awal = $awal; }
			$akhir	= $per_page;
		
			$a['pagi']	= _page($total_row, $per_page, 4, base_url()."general/manageusers/p");
		
			//ambil variabel URL
			$mau_ke					= $this->uri->segment(3);
			$idu					= $this->uri->segment(4);
		
			$cari					= addslashes($this->input->post('q'));

			//ambil variabel Postingan
			//$idp					= addslashes($this->input->post('idp'));
			$username				= addslashes($this->input->post('user'));
			$password				= md5(addslashes($this->input->post('passwd')));
			$nama					= addslashes($this->input->post('name'));
			$nip					= addslashes($this->input->post('nik'));
			$level					= addslashes($this->input->post('level'));
		
			$cari					= addslashes($this->input->post('q'));

		
			if ($mau_ke == "del") 
			{
				$this->db->query("DELETE FROM m_users WHERE uid = '$idu'");
				$this->session->set_flashdata("k", "<div class=\"alert alert-success\" id=\"alert\">Data has been deleted </div>");
				redirect('index.php/general/manageusers');
			} 
			else if ($mau_ke == "find") 
			{
				$a['data']		= $this->db->query("SELECT * FROM m_users WHERE fname LIKE '%$cari%' ORDER BY uid DESC")->result();
				$a['page']		= "lmanageusers";
			} 
			else if ($mau_ke == "add") 
			{
				$a['page']		= "fmanageusers";
			} 
			else if ($mau_ke == "edt") 
			{
				$a['datpil']	= $this->db->query("SELECT * FROM m_users WHERE uid = '$idu'")->row();	
				$a['page']		= "fmanageusers";
			} 
			else if ($mau_ke == "act_add") 
			{	
				$cek_user_exist = $this->db->query("SELECT uid FROM m_users WHERE uid = '$username'")->num_rows();

				if (strlen($username) < 2) 
				{
					$this->session->set_flashdata("k", "<div class=\"alert alert-danger\" id=\"alert\">Username minimal 6 huruf</div>");
				} 
				else if ($cek_user_exist > 0) 
				{
					$this->session->set_flashdata("k", "<div class=\"alert alert-danger\" id=\"alert\">Username exists. Choose another one...!</div>");	
				} 
				else 
				{
					$this->db->query("INSERT INTO m_users VALUES ('$username', '$password', '$nama', '$nip', '$level')");
					$this->session->set_flashdata("k", "<div class=\"alert alert-success\" id=\"alert\">Data has been added</div>");
				}
			
				//$this->session->set_flashdata("k", "<div class=\"alert alert-success\" id=\"alert\">Data has been added</div>");
				//echo $username;
				redirect('index.php/general/manageusers');
			} 
			else if ($mau_ke == "act_edt") 
			{
				if ($password = md5("-")) 
				{
					$this->db->query("UPDATE m_users SET uid = '$username', fname = '$nama', nik = '$nip', level = '$level' WHERE uid = '$username'");
				} 
				else 
				{
					$this->db->query("UPDATE m_users SET uid = '$username', pwd = '$password', fname = '$nama', nik = '$nip', level = '$level' WHERE uid = '$username'");
				}
			
				$this->session->set_flashdata("k", "<div class=\"alert alert-success\" id=\"alert\">Data has been updated </div>");			
				redirect('index.php/general/manageusers');
			} 
			else 
			{
				$a['data']		= $this->db->query("SELECT * FROM m_users LIMIT $awal, $akhir ")->result();
				$a['page']		= "lmanageusers";
			}
		
			$this->load->view('aaa', $a);
		}
	
		public function passwod() 
		{
			if ($this->session->userdata('admin_valid') == FALSE && $this->session->userdata('admin_id') == "") 
			{
				redirect("index.php/general/login");
			}
		
			$ke				= $this->uri->segment(3);
			$id_user		= $this->session->userdata('admin_id');
		
			//var post
			$p1				= md5($this->input->post('p1'));
			$p2				= md5($this->input->post('p2'));
			$p3				= md5($this->input->post('p3'));
		
			if ($ke == "simpan") 
			{
				$cek_password_lama	= $this->db->query("SELECT password FROM m_users WHERE uid = $id_user")->row();
				//echo 
			
				if ($cek_password_lama->password != $p1) 
				{
					$this->session->set_flashdata('k_passwod', '<div id="alert" class="alert alert-error">Old Password does not match...</div>');
					redirect('index.php/general/passwod');
				} 
				else if ($p2 != $p3) 
				{
					$this->session->set_flashdata('k_passwod', '<div id="alert" class="alert alert-error">New Password 1 and 2 does not match...</div>');
					redirect('index.php/general/passwod');
				} 
				else 
				{
					$this->db->query("UPDATE m_users SET pwd = '$p3' WHERE uid = ".$id_user."");
					$this->session->set_flashdata('k_passwod', '<div id="alert" class="alert alert-success">Password changed...</div>');
					redirect('index.php/general/passwod');
				}
			} 
			else 
			{
				$a['page']	= "fpasswd";
			}
		
			$this->load->view('aaa', $a);
		}
	
		//login
		public function login() 
		{
			$this->load->view('login');
		}
	
		public function do_login() 
		{
			$u 		= $this->security->xss_clean($this->input->post('u'));
			$ta 	= $this->security->xss_clean($this->input->post('ta'));
			$p 		= md5($this->security->xss_clean($this->input->post('p')));
         
			$q_cek	= $this->db->query("SELECT * FROM m_users WHERE uid = '".$u."' AND pwd = '".$p."'");
			$j_cek	= $q_cek->num_rows();
			$d_cek	= $q_cek->row();
			//echo $this->db->last_query();
		
			if($j_cek == 1) 
			{
				$data = array(
						//'admin_id' => $d_cek->id,
						'admin_user' => $d_cek->uid,
						'admin_nama' => $d_cek->fname,
						'admin_ta' => $ta,
						'admin_level' => $d_cek->level,
						'admin_valid' => true
						);
				$this->session->set_userdata($data);
				redirect('index.php/general');
			} 
			else 
			{	
				$this->session->set_flashdata("k", "<div id=\"alert\" class=\"alert alert-error\">username or password is not valid</div>");
				redirect('index.php/general/login');
			}
		}
	
		public function logout()
		{
			$this->session->sess_destroy();
			redirect('index.php/general/login');
		}
	}
?>