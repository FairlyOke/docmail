<?php 
	if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Docnum extends CI_Controller 
	{
		function __construct() 
		{
			parent::__construct();
			$this->load->database();
			$this->load->helper(array('url'));
			$this->load->model('Mdocnum');
		}
	
		public function index()
		{
			if ($this->session->userdata('admin_valid') == FALSE && $this->session->userdata('admin_id') == "") 
			{
				redirect("index.php/general/login");
			}	
		
			$a['page']	= "d_amain";
			$this->load->view('aaa', $a);			
		}
	
		function getoffice()
		{
			$modul=$this->input->post('modul');
			$id=$this->input->post('id');
			
			if($modul=="kabupaten")
			{
				echo $this->Mdocnum->getoffice($id);
			}
			else
			{
				
			}
		}
		
		public function docnumlist() 
		{
			if ($this->session->userdata('admin_valid') == FALSE && $this->session->userdata('admin_id') == "") 
			{
				redirect("index.php/general/login");
			}
		
			/* pagination */				
			$total_row		= $this->Mdocnum->recordlist();
			$per_page		= 10;
		
			$awal	= $this->uri->segment(4); 
			$awal	= (empty($awal) || $awal == 1) ? 0 : $awal;
		
			//if (empty($awal) || $awal == 1) { $awal = 0; } { $awal = $awal; }
			$akhir	= $per_page;
		
			$a['pagi']	= _page($total_row, $per_page, 4, base_url()."index.php/docnum/docnumlist/p");
		
			//ambil variabel URL
			$mau_ke					= $this->uri->segment(3);
			$idu					= $this->uri->segment(4);
		
			$cari					= addslashes($this->input->post('q'));

			//ambil variabel Postingan			
			$code					= addslashes($this->input->post('code'));
			$descr					= addslashes($this->input->post('descr'));
			$cari					= addslashes($this->input->post('q'));
		
			if ($mau_ke == "find") 
			{
				$a['data']	= $this->Mdocnum->find($cari);
				$a['page']	= "vldocnum";
			} 
			else
			{
				$a['data']	= $this->Mdocnum->paginglist($awal, $akhir);
				$a['page']	= "vldocnum";
			}
			
			$this->load->view('aaa', $a);
		}
	
		public function docnumrecord() 
		{
			if ($this->session->userdata('admin_valid') == FALSE && $this->session->userdata('admin_id') == "") 
			{
				redirect("index.php/general/login");
			}
		
			$ta = $this->session->userdata('admin_ta');
		
			/* pagination */	
			$total_row		= $this->Mdocnum->recordlist();
			$per_page		= 10;
		
			$awal	= $this->uri->segment(4); 
			$awal	= (empty($awal) || $awal == 1) ? 0 : $awal;
		
			//if (empty($awal) || $awal == 1) { $awal = 0; } { $awal = $awal; }
			$akhir	= $per_page;
		
			$a['pagi']	= _page($total_row, $per_page, 4, base_url()."index.php/docnum/docnumlist/p");
		
			//ambil variabel URL
			$mau_ke					= $this->uri->segment(3);
			$idu1					= $this->uri->segment(4);
			$idu2					= $this->uri->segment(5);
			$idu3					= $this->uri->segment(6);
			$idu4					= $this->uri->segment(7);
			$idu5					= $this->uri->segment(8);
			$idu6					= $this->uri->segment(9);
			$idu7					= $this->uri->segment(10);
			$idu8					= $this->uri->segment(11);
			$idu9					= $this->uri->segment(12);
			
			$idu					= $idu1.'/'.$idu2.'/'.$idu3.'/'.$idu4.'/'.$idu5.'/'.$idu6.'/'.$idu7.'/'.$idu8.'/'.$idu9;
			
			$cari					= addslashes($this->input->post('q'));

			//ambil variabel post
			$idp					= addslashes($this->input->post('idp'));
			$code					= addslashes($this->input->post('code'));
			$descr 				    = addslashes($this->input->post('descr'));			
			
			$cari					= addslashes($this->input->post('q'));
			
			//upload config 
			$config['upload_path'] 		= './upload/surat_masuk';
			$config['allowed_types'] 	= 'gif|jpg|png|pdf|doc|docx';
			$config['max_size']			= '2000';
			$config['max_width']  		= '3000';
			$config['max_height'] 		= '3000';

			$this->load->library('upload', $config);

			if ($mau_ke == "del") 
			{
				$this->Mdocnum->delet($idu);
				$this->session->set_flashdata("k", "<div class=\"alert alert-success\" id=\"alert\">Data has been deleted </div>");
				redirect('index.php/docnum/docnumlist');
			} 
			else if ($mau_ke == "add") 
			{
				$a['headoffice'] = $this->Mdocnum->getheadoffice();
				//$a['office'] = $this->Mdocnum->getoffice();
				$a['darma']  = $this->Mdocnum->getdarma();
				$a['fungsi'] = $this->Mdocnum->getfungsi();
				$a['prodi']  = $this->Mdocnum->getprodi();
				$a['months']  = $this->Mdocnum->getmonths();
				$a['years']  = $this->Mdocnum->getyears();
				$a['page']	 = "vfdocnumadd";
			} 
			else if ($mau_ke == "edt") 
			{
				$a['datpil']	= $this->Mdocnum->edit($idu);
				$a['page']		= "vfdocnumedit";
			} 			
			else if ($mau_ke == "viw") 
			{
				$a['data']	= $this->Mdocnum->edit($idu);
				$a['page']		= "vldocnumview";
			}
			else if ($mau_ke == "act_add") 
			{	
				$a['datpil']	= $this->Mdocnum->edit($idu);
				$a['page']		= "vfdocnumgenerate";
				
				/*$this->Mdocnum->actadd($code, $descr);
				
				$this->session->set_flashdata("k", "<div class=\"alert alert-success\" id=\"alert\">Data has been added. ".$this->upload->display_errors()."</div>");
				redirect('index.php/docnum/docnumrecord');*/
			} 
			else if ($mau_ke == "act_edt") 
			{
				$this->Mdocnum->actedit($code, $descr);
				
				$this->session->set_flashdata("k", "<div class=\"alert alert-success\" id=\"alert\">Data has been updated. ".$this->upload->display_errors()."</div>");			
				redirect('index.php/docnum/docnumrecord');
			} 
			else 
			{
				$a['data']		= $this->Mdocnum->paginglist($awal, $akhir);
				$a['page']		= "vldocnumadd";
			}
		
			$this->load->view('aaa', $a);
		}
		
		public function docnumgenerate() 
		{
			if ($this->session->userdata('admin_valid') == FALSE && $this->session->userdata('admin_id') == "") 
			{
				redirect("index.php/general/login");
			}
		
			$ta = $this->session->userdata('admin_ta');
			
			$maildoc = $this->input->post('maildoc');
			$month	 = $this->input->post('month');			
			$year	 = $this->input->post('year');
			$docdate = $this->input->post('docdate');
			$docdate = date("Y-m-d", strtotime($docdate));
			$ho 	 = $this->input->post('ho');
			$off 	 = $this->input->post('off');
			$dar	 = $this->input->post('dar');
			$fun 	 = $this->input->post('fun');
			$pro	 = $this->input->post('pro');
			$title	 = $this->input->post('title');
			$mailto	 = $this->input->post('mailto');
			$mailpic = $this->input->post('mailpic');
			$descr	 = $this->input->post('descr');
			
			$docnum = $this->Mdocnum->search($ho);
			
			$finum = $maildoc.'/'.$ho.'/'.$docnum.'/'.$month.'/'.$year.'/'.$off.'/'.$dar.'/'.$fun.'/'.$pro;
			
			$a['data']    = $finum;			
			$a['data']    = $title;			
			$a['docnum']  = $finum;			
			$a['docdate'] = $docdate;
			$a['title']   = $title;			
			$a['page']	  = "vldocnumgenerate";
			
			$this->Mdocnum->actadd($finum, $title, $maildoc, $month, $year, $docdate, $ho, $off, $dar, $fun, $pro, $descr, $mailto, $mailpic);
			
			$this->load->view('aaa', $a);
		}
	
	}
?>